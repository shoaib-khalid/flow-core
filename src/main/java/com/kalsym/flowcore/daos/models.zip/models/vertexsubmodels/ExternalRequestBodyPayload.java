package com.kalsym.flowcore.daos.models.vertexsubmodels;

import lombok.Getter;
import lombok.Setter;

/**
 *
 * @author Sarosh
 */
@Getter
@Setter
public class ExternalRequestBodyPayload {

    private String parameter;
    private String value;
}
