package com.kalsym.flowcore.daos.models.vertexsubmodels;

import lombok.Getter;
import lombok.Setter;

/**
 *
 * @author Sarosh
 */
@Getter
@Setter
public class ExternalRequestResponseMapping {

    private String dataVariable;
    private String path;
    private boolean optional;
}
